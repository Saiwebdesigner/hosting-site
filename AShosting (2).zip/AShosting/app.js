document.querySelector("#openslide").addEventListener("click",function(e){
    document.querySelector(".mobile").style.width="250px";
    e.preventDefault();
});
document.querySelector("#btnbnd").addEventListener("click",function(e){
    document.querySelector(".mobile").style.width="0px";

    e.preventDefault();
});